<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <button>start anmiton</button>
    <div style="background:#213ebf;height:100px;width:100px;position:absolute;"></div>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
<script>
     $(document).ready(function(){
        $("button").click(function(){
            $("div").animate({left:'500px'});
        })
     })
    </script>

</body>
</html>